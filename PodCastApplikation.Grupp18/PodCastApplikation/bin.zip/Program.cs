using PodCastApplikation.Business;
using PodCastApplikation.Business.Validation;
using PodCastApplikation.DAL;


namespace PodCastApplikation
{
    internal static class Program
    {
        
        [STAThread]
        static async Task Main()
        {
            var repo = new KategoriRepository();
            var alla = await repo.H�mtaAllaKategorier();
            Console.WriteLine($"Antal kategorier: {alla.Count}");

            ApplicationConfiguration.Initialize();

            var rssH�mtare = new RssH�mtare();
            var poddRepository = new PoddRepository();
            var kategoriRepository = new KategoriRepository();

            var poddService = new PoddService(rssH�mtare, poddRepository, kategoriRepository);

           
            Application.Run(new Form1(poddService));


       
            
           
        }
    }
}